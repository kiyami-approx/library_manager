#ifndef __BOOK_CHECK_H
#define __BOOK_CHECK_H

void check_book_by_name(char target_book_name[50]);
void check_book_by_writer(char target_writer_name[30]);
void check_book_by_id(char target_id[40]);

#endif
