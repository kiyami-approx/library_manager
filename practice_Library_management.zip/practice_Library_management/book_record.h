#ifndef __BOOK_RECORD_H
#define __BOOK_RECORD_H

struct Book
{
    char book_id[40];
    char book_writer[30];
    char book_name[50];
    
};

extern int book_total_num;
extern struct Book book[10000];
extern char *booklist[10000];
extern char *writerlist[500];
extern struct Book current_book[10000];
extern int current_book_total_num;

int book_num_record(char target_book_name[50]);
void book_id_record(char target_book_name[50]);
void book_writer_record(char target_book_name[50]);
int book_list_build();
void show_all_book();

#endif
