#ifndef __BOOK_DELETE_H
#define __BOOK_DELETE_H

void delete_book(void);


#endif
