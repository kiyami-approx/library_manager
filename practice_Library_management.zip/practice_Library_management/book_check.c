#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "book_record.h"
#include "book_add.h"
#include "book_check.h"
#include "book_delete.h"
#include "book_lead_back.h"

void check_book_by_name(char target_book_name[50])
{
    book_writer_record(target_book_name);
    book_id_record(target_book_name);
    book_num_record(target_book_name);
}

void check_book_by_writer(char target_writer_name[30])
{   
    int found = 0;
    int writer_booklist_point_sign = 0;
    char *writer_booklist[100];    //建立一个由该作者写的书的清单

    for (int k = 0; k < book_total_num; k++) 
    {
        if (writer_booklist[k] != NULL) 
        {
            free(writer_booklist[k]);
            writer_booklist[k] = NULL;
        }
    }

    for(int i = 0;i < book_total_num;i++)
    {
        if (strcmp(book[i].book_writer,target_writer_name) == 0)
        {
            found = 1;
            int found_samebook = 0;
            for (int j = 0;j < writer_booklist_point_sign;j++)
            {   
                if(strcmp(writer_booklist[j],book[i].book_name) == 0)
                {
                    found_samebook = 1;
                    break;
                }   
            }
            if (found_samebook == 0)
            {   
                writer_booklist[writer_booklist_point_sign] = (char*)malloc(strlen(book[i].book_name)+1);
                strcpy(writer_booklist[writer_booklist_point_sign],book[i].book_name);
                writer_booklist_point_sign ++;
            }
        }
    }

    if (found == 0)
    {
        printf("图书馆未录入该作者的作品\r\n");
    }
    else 
    {
        for (int i = 0;i < writer_booklist_point_sign;i++)
        {   
            printf("------------------------\r\n");
            printf("书目：%s，馆藏情况如下\r\n",writer_booklist[i]);
            book_id_record(writer_booklist[i]);
            book_num_record(writer_booklist[i]);
            printf("------------------------\r\n");
        }
    }
    for (int k = 0; k < writer_booklist_point_sign; k++) 
    {
        if (writer_booklist[k] != NULL) 
        {
            free(writer_booklist[k]);
            writer_booklist[k] = NULL;
        }
    }
}

void check_book_by_id(char target_id[40])
{
    int found = 0;
    char get_bookname[50];
    for (int i = 0;i < book_total_num;i++)
    {
        if (strcmp(book[i].book_id,target_id) == 0)
        {
            found = 1;
            strcpy(get_bookname,book[i].book_name);
            break;
        }
    }
    if (found == 0)
    {
        printf("未查询到该ID对应的图书\r\n");
    }
    else
    {
        printf("查询到以下内容\r\n");
        printf("书名为：%s\r\n",get_bookname);
        book_writer_record(get_bookname);
        book_num_record(get_bookname);
        book_id_record(get_bookname);
    }
}