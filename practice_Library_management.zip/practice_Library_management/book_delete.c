#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "book_record.h"
#include "book_add.h"
#include "book_check.h"
#include "book_delete.h"
#include "book_lead_back.h"

void delete_book(void)
{   
    // 第一步：管理员密码认证（和add_book逻辑一致）
    char key[8];
    printf("请输入管理员密码\r\n");
    scanf("%7s",key);
    while (getchar() != '\n');
    if (strcmp(key,"1111") != 0)
    {
        printf("权限不足，无法删除图书\r\n");
        return;
    }
    printf("欢迎管理员，开始执行删除操作\r\n");

    // 第二步：判断是否有图书可删
    if (book_total_num <= 0)
    {
        printf("未录入任何图书，无可删除的图书\r\n");
        return;
    }

    // 第三步：输入要删除的图书ID
    char del_id[40];
    printf("请输入要删除的图书ID：\r\n");
    scanf("%s", del_id);
    while (getchar() != '\n');

    // 第四步：查找目标ID的图书下标
    int delete_index = -1;
    for (int i = 0; i < book_total_num; i++)
    {
        if (strcmp(book[i].book_id, del_id) == 0)
        {
            delete_index = i;
            break;
        }
    }

    // 第五步：未找到目标ID的处理
    if (delete_index == -1)
    {
        printf("未找到ID为【%s】的图书，删除失败\r\n", del_id);
        return;
    }

    // 第六步：核心删除逻辑（数组元素前移覆盖）
    for (int j = delete_index; j < book_total_num - 1; j++)
    {
        strcpy(book[j].book_id, book[j+1].book_id);
        strcpy(book[j].book_name, book[j+1].book_name);
        strcpy(book[j].book_writer, book[j+1].book_writer);
    }

    // 第七步：清空最后一个残留元素，避免脏数据
    memset(&book[book_total_num - 1], 0, sizeof(struct Book));
    
    // 第八步：总数减1并提示
    book_total_num -= 1;
    printf("删除完成！当前图书馆藏书量：%d（上限10000）\r\n", book_total_num);

        // 在delete_book函数的“book_total_num -= 1;”前添加：
    // 同步删除current_book中的对应图书
    int curr_del_idx = -1;
    for (int m = 0; m < current_book_total_num; m++) {
        if (strcmp(current_book[m].book_id, del_id) == 0) {
            curr_del_idx = m;
            break;
        }
    }
    if (curr_del_idx != -1) 
    {
        for (int n = curr_del_idx; n < current_book_total_num - 1; n++) 
        {
            strcpy(current_book[n].book_id, current_book[n+1].book_id);
            strcpy(current_book[n].book_name, current_book[n+1].book_name);
            strcpy(current_book[n].book_writer, current_book[n+1].book_writer);
        }
        memset(&current_book[current_book_total_num - 1], 0, sizeof(struct Book));
        current_book_total_num -= 1;
        printf("同步删除在馆库存，当前在馆图书数：%d\r\n", current_book_total_num);
    }
}