#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "book_record.h"
#include "book_add.h"
#include "book_check.h"
#include "book_delete.h"
#include "book_lead_back.h"



void lead_book(void)
{   
    printf("欢迎读者借书\r\n");
    
    if (book_total_num <= 0)
    {
        printf("未录入任何图书，无可借阅图书\r\n");
        return;
    }
    if (current_book_total_num <= 0)
    {
        printf("图书已全部借出,无可借阅图书\r\n");
        return;
    }
    
    char lead_book_name[50];
    printf("请输入要借阅的图书名：\r\n");
    scanf("%49s", lead_book_name);
    while (getchar() != '\n');
    
    printf("以下是该书的所有信息\r\n");
    check_book_by_name(lead_book_name);
    
    
    char lead_book_id[40];
    printf("请输入你要借出书目的ID:\r\n");
    scanf("%39s",lead_book_id);
    while (getchar() != '\n');

    int lead_index = -1;
    for (int i = 0; i < current_book_total_num; i++)
    {
        if (strcmp(current_book[i].book_id, lead_book_id) == 0)
        {
            lead_index = i;
            break;
        }
    }

    if (lead_index == -1)
    {
        printf("未找到ID为【%s】的图书，借出失败\r\n", lead_book_id);
        return;
    }

    for (int j = lead_index; j < current_book_total_num - 1; j++)
    {
        strcpy(current_book[j].book_id, current_book[j+1].book_id);
        strcpy(current_book[j].book_name, current_book[j+1].book_name);
        strcpy(current_book[j].book_writer, current_book[j+1].book_writer);
    }

    memset(&current_book[current_book_total_num - 1], 0, sizeof(struct Book));
    current_book_total_num -= 1;
    printf("成功！当前图书可借阅量：%d\r\n", current_book_total_num);
}

void back_book(void)
{   
    char back_book_id[40];
    printf("请输入你要归还的图书的id\r\n");
    scanf("%39s",back_book_id);
    int back_book_id_found = 0;
    int back_index = -1;
    for (int i = 0;i < book_total_num; i++)
    {
        if (strcmp(book[i].book_id,back_book_id) == 0)
        {
            back_book_id_found = 1;
            back_index = i;
            break;
        } 
    }
    for (int j = 0;j < current_book_total_num;j++)
    {
        if (strcmp(current_book[j].book_id,back_book_id) == 0)
        {
            back_book_id_found = 2;
        }
    }
    if (back_book_id_found == 0)
    {
        printf("未录入此id，还书失败\r\n");
        return;
    }
    if (back_book_id_found == 2)
    {
        printf("该图书在馆,错误归还\r\n");
        return;
    }
    strcpy(current_book[current_book_total_num].book_id,back_book_id); 
    strcpy(current_book[current_book_total_num].book_name,book[back_index].book_name);
    strcpy(current_book[current_book_total_num].book_writer,book[back_index].book_writer);
    current_book_total_num += 1;
    printf("还书成功\r\n");
}