#ifndef __BOOK_ADD_H
#define __BOOK_ADD_H


void add_book();




#endif
