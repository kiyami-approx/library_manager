#include <stdio.h>
#include <string.h>
#include "book_record.h"
#include "book_add.h"
#include "book_check.h"
#include "book_delete.h"
#include "book_lead_back.h"

void add_book()
{   
    char key[8];
    printf("请输入管理员密码\r\n");
    scanf("%7s",key);
    while (getchar() != '\n');
    if (strcmp(key,"1111") == 0)
    {   
        printf("欢迎管理员\r\n");
        int flag = 0;
        
        if (book_total_num <10000)
        {   
            int i;
            for (i = book_total_num; i < 10000;i++)
            {   
                printf("------------------------\r\n");
                printf("请输入图书ID：\r\n");
                scanf("%39s",book[i].book_id);
                printf("请输入图书作者：\r\n");
                scanf("%29s",book[i].book_writer);
                printf("请输入图书名称：\r\n");
                scanf("%49s",book[i].book_name);
                book_total_num +=1; 
                strcpy(current_book[current_book_total_num].book_writer,book[i].book_writer);
                strcpy(current_book[current_book_total_num].book_name,book[i].book_name);
                strcpy(current_book[current_book_total_num].book_id,book[i].book_id);                  
                current_book_total_num += 1;
                printf("添加成功！当前图书总数：%d\r\n", book_total_num);
                printf("当前在馆图书总数：%d\r\n",current_book_total_num);
                printf("------------------------\r\n");
                printf("如需停止添加，请按1，否则按任意其他键继续\r\n");
                scanf("%d",&flag);
                while (getchar() != '\n');
                if (flag == 1)
                {
                    break;
                }
                else
                {
                    printf("继续添加\r\n");
                }
            }
        }
        else
        {
            printf("图书数量已达上限，无法添加\r\n");
        }
    }
    else
    {
        printf("权限不足，无法添加图书\r\n");
    }
}