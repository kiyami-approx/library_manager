#include <stdio.h>
#include <string.h>
#include "book_record.h"
#include "book_add.h"
#include <stdlib.h>
#include "book_check.h"
#include "book_delete.h"
#include "book_lead_back.h"

char *booklist[10000];
char *writerlist[500];
int book_total_num = 0;
struct Book book[10000];
struct Book current_book[10000];
int current_book_total_num = 0;

/*
 *  brief 这是简易图书馆的主界面，包含管理员添加，除去书目，显示所有书目，查阅书目，借阅与还书
 *  param 无
 *  retval 无  
 */
int main()
{   
    while(1)
    {   
        printf("------------------------\r\n");
        printf("------------------------\r\n");
        printf("------------------------\r\n");
        printf("如需添加图书，请按1\r\n");
        printf("如需查看所有图书，请按2\r\n");
        printf("如需查询指定图书，请按3\r\n");
        printf("如需删除图书，请按4\r\n"); 
        printf("如需借阅图书，请按5\r\n"); 
        printf("如需归还图书，请按6\r\n");
        printf("如需退出系统，请按7\r\n");
        int input = 0;
        int exit_flag = 0;
        // main函数中替换原scanf("%d",&input);
        while (scanf("%d", &input) != 1)
        {
            while (getchar() != '\n');
            printf("输入不是数字，请重新选择：\r\n");
        }
        while (getchar() != '\n'); // 清理后续换行
        system("cls");
        switch (input)
        {
            case 1:
            {
                add_book();
                break;        
            }

            case 2:
            {   
                show_all_book();
                break;
            }

            case 3:
            {   
                printf("按书名查找请按1，按作者名查找请按2，按ID查找请按3\r\n");
                int input2 = 0;
                scanf("%d",&input2);
                system("cls");
                switch (input2)
                {   
                    case 1:
                    {   
                        char a[50];
                        printf("请输入要查询的书名\r\n");
                        scanf("%49s",a);
                        system("cls");
                        check_book_by_name(a);
                        break;
                    }
                    case 2:
                    {   
                        char b[30];
                        printf("请输入要查询的作者\r\n");
                        scanf("%29s",b);
                        system("cls");
                        check_book_by_writer(b);
                        break;
                    }
                    case 3:
                    {
                        char c[40];
                        printf("请输入要查询的ID\r\n");
                        scanf("%39s",c);
                        system("cls");
                        check_book_by_id(c);
                        break;
                    }    
                    default:
                        {break;}
                }
                break;
            }
            case 4: // 新增删除功能入口
            {
                delete_book(); // 传空字符串，认证逻辑在函数内处理
                break;
            }
            case 5:
            {
                lead_book();
                break;
            }
            case 6:
            {
                back_book();
                break;
            }
            case 7:
            {
                exit_flag = 1;
                break;
            }

            default:
            {
                printf("输入非法，请重新选择\r\n");
                break;
            }
        }
        if (exit_flag == 1)
        {
            printf("已退出系统，感谢使用\r\n");
            for (int k = 0; k < book_total_num; k++) 
            {
                if (booklist[k] != NULL) 
                {
                    free(booklist[k]);
                    booklist[k] = NULL;
                }
            }
            break;
        }
    }
    return 0;
}