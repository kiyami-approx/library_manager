#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "book_record.h"
#include "book_add.h"
#include "book_check.h"
#include "book_delete.h"
#include "book_lead_back.h"

/*
 * brief 这是记录某本书目数量的函数
 * param 目标书目名
 * retval 目标书目馆藏数量
 */
int book_num_record(char target_book_name[50])
{   
    int book_num = 0;
    int current_book_num =0;
    for (int i = 0;i < book_total_num;i++)
    {
        if(strcmp(book[i].book_name,target_book_name) == 0)
        {
            book_num += 1;
        }
    }
    for (int i = 0;i < current_book_total_num;i++)
    {
        if(strcmp(current_book[i].book_name,target_book_name) == 0)
        {
            current_book_num += 1;
        }
    }
    printf("馆藏数量：%d\r\n",book_num);
    printf("馆现有数量：%d\r\n",current_book_num);
    return book_num;
}

/*
 * brief 这是记录某本书目所有id的函数
 * param 目标书目名
 * retval 无
 */
void book_id_record(char target_book_name[50])
{
    for (int i = 0;i < book_total_num;i++)
    {
        if(strcmp(book[i].book_name,target_book_name) == 0)
        {
            printf("图书ID：%s已录入图书馆系统\r\n",book[i].book_id);
        }
    }
    for (int i = 0;i < current_book_total_num;i++)
    {
        if(strcmp(current_book[i].book_name,target_book_name) == 0)
        {
            printf("图书ID：%s现存于图书馆\r\n",current_book[i].book_id);
        }
    }
}

/*
 * brief 这是记录某本书目作者的函数
 * param 目标书目名
 * retval 无
 */
void book_writer_record(char target_book_name[50])
{
    for (int i = 0;i < book_total_num;i++)
    {
        if(strcmp(book[i].book_name,target_book_name) == 0)
        {
            printf("作者：%s\r\n",book[i].book_writer);
            break;
        }
    }
}

// 这是一个建立书目清单的函数
int book_list_build()
{   
    int book_point_sign = 0;
    // 第一步：先清空旧的booklist（避免内存泄漏+野指针）
    for (int k = 0; k < book_total_num; k++) 
    {
        if (booklist[k] != NULL) 
        {
            free(booklist[k]);
            booklist[k] = NULL;
        }
    }
    // 第二步：正确去重（只遍历已添加的图书，且只对比已去重的booklist）
    for (int i = 0;i < book_total_num;i++)
    {   
        int found = 0;
        // 关键：j < book_point_sign_（只对比已经加入booklist的元素，不是book_total_num）
        for (int j = 0;j < book_point_sign;j++)
        {
            // 此时booklist[j]已经被malloc初始化，不会野指针
            if (strcmp(booklist[j], book[i].book_name) == 0)
            {   
                found = 1;
                break;
            } 
        }
        if (found == 0)
        {
            // 关键：深拷贝书名到booklist，避免野指针
            booklist[book_point_sign] = (char*)malloc(strlen(book[i].book_name) + 1);
            strcpy(booklist[book_point_sign], book[i].book_name);
            book_point_sign ++;
        }
    }
    return book_point_sign;
}

void show_all_book()
{   
    // 新增：打印总数（验证函数是否执行）
    printf("===== 开始查看所有图书 =====\r\n");
    printf("当前图书总数：%d\r\n", book_total_num); 
    printf("当前馆内现存书量：%d\r\n",current_book_total_num);
    if (book_total_num == 0)
    {
        printf("您尚未添加任何图书\r\n");
    }
    else
    {
        int book_list_num = 0;
        book_list_num = book_list_build();
        printf("去重后图书种类数：%d\r\n", book_list_num); // 新增：验证去重结果
        printf("以下是所有图书信息\r\n");
        printf("------------------------\r\n");
        for(int i = 0;i < book_list_num;i++)
        {   
            printf("------------------------\r\n");
            printf("书名：%s\r\n",booklist[i]);
            book_writer_record(booklist[i]);
            book_num_record(booklist[i]);
            book_id_record(booklist[i]);
        }
        printf("------------------------\r\n");
    }
}