#ifndef __BOOK_LEAD_BACK_H
#define __BOOK_LEAD_BACK_H

void back_book(void);
void lead_book(void);

#endif
